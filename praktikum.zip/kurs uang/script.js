function konversiUang() {
    let nilai = Number(document.getElementById("nilai").value);
    let daftar = Number(document.getElementById("listmatauang").value);

    let hasilKonversi = nilai * daftar;
    document.getElementById("hasil").value = hasilKonversi; 
}